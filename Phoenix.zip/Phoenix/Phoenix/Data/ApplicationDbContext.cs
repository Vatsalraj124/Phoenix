﻿using Microsoft.EntityFrameworkCore;
using Phoenix.Models;

namespace Phoenix.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // This will map the User model to a table in MySQL database
        public DbSet<User> Users { get; set; }

        // For Animal model
        public DbSet<Animal> Animals { get; set; }

        
    }
}
