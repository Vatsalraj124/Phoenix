using Microsoft.EntityFrameworkCore;
using Phoenix.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
    new MySqlServerVersion(new Version(8, 0, 25))));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Account/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Configure routes
app.MapControllerRoute(
    name: "default",
    pattern: "/",
    defaults: new { controller = "Account", action = "SignIn" });

app.MapControllerRoute(
    name: "sign-in",
    pattern: "sign-in",
    defaults: new { controller = "Account", action = "SignIn" });

app.MapControllerRoute(
    name: "sign-up",
    pattern: "sign-up",
    defaults: new { controller = "Account", action = "SignUp" });

app.MapControllerRoute(
    name: "dashboard",
    pattern: "dashboard",
    defaults: new { controller = "Home", action = "Dashboard" });

app.MapControllerRoute(
    name: "wizards",
    pattern: "wizards",
    defaults: new { controller = "Animal", action = "Index" });

app.MapControllerRoute(
    name: "wizardscreate",
    pattern: "wizards/create",
    defaults: new { controller = "Animal", action = "Create" });

app.MapControllerRoute(
    name: "wizardsedit",
    pattern: "wizards/edit/{id?}",
    defaults: new { controller = "Animal", action = "Edit" });

app.MapControllerRoute(
    name: "wizardsdelete",
    pattern: "wizards/delete/{id?}",
    defaults: new { controller = "Animal", action = "Delete" });

app.MapControllerRoute(
    name: "explore",
    pattern: "explore",
    defaults: new { controller = "Explore", action = "Index" });



app.Run();
