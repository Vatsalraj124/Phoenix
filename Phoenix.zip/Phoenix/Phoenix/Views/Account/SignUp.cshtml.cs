using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Phoenix.Views.Account
{
    public class SignUpModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
