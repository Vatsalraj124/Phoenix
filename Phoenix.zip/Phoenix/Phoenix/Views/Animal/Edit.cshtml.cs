using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Phoenix.Views.Wizards
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
