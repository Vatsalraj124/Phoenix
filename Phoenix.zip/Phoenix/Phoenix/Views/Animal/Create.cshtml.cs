using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Phoenix.Views.Wizards
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
