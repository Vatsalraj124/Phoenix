using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Phoenix.Views.Wizards
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
