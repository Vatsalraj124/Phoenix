using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Phoenix.Views.Explore
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
