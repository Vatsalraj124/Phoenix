﻿// Controllers/ExploreController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore; // Ensure this is included
using Phoenix.Data; // Your data context namespace
using Phoenix.Models; // Your model namespace
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Phoenix.Controllers
{
    public class ExploreController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ExploreController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var animals = await _context.Animals.ToListAsync(); // This should now work
            return View(animals);
        }
    }
}
