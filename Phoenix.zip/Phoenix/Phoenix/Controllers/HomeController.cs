﻿using Microsoft.AspNetCore.Mvc;

namespace Phoenix.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home/Dashboard
        public IActionResult Dashboard()
        {
            // You can pass any data or model to the view if needed
            return View();
        }
    }
}
