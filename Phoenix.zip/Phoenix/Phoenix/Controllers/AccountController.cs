﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Phoenix.Data;
using Phoenix.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace Phoenix.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Account/SignUp
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }

        // POST: Account/SignUp
        [HttpPost]
        public async Task<IActionResult> SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                // Hash the password before saving (without salt)
                user.Password = HashPassword(user.Password);

                // Check if the username already exists
                if (_context.Users.Any(u => u.Username == user.Username))
                {
                    ModelState.AddModelError("Username", "Username is already taken.");
                    return View(user);
                }

                // Save user to the database
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction("SignIn");
            }
            return View(user);
        }

        // GET: Account/SignIn
        [HttpGet]
        public IActionResult SignIn()
        {
            return View();
        }

        // POST: Account/SignIn
        [HttpPost]
        public IActionResult SignIn(string Role, string Username, string Password)
        {
            // Hash the input password for comparison
            string hashedPassword = HashPassword(Password);

            // Find user in the database
            var user = _context.Users
                .FirstOrDefault(u => u.Role == Role && u.Username == Username && u.Password == hashedPassword);

            if (user != null)
            {
                // Redirect to the Dashboard action in the HomeController
                return RedirectToAction("Dashboard", "Home");
            }

            // Add an error if login failed
            ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            return View();
        }

        // Hashing the password for security (without salt)
        private string HashPassword(string password)
        {
            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: new byte[0],  // No salt
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 32));

            return hashed;
        }
    }
}
