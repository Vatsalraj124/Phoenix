﻿namespace Phoenix.Models
{
    public class Role
    {
        public const string Admin = "Admin";
        public const string Visitor = "Visitor";
    }
}
