﻿namespace Phoenix.Models
{
    public class Animal
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty; // Animal name
        public string ImageUrl { get; set; } = string.Empty; // URL or path to the image
        public string CageNo { get; set; } = string.Empty; // Cage number
        public string Description { get; set; } = string.Empty; // Description of the animal
        public string Species { get; set; } = string.Empty; // Animal species
        public string Diet { get; set; } = string.Empty; // Animal diet
        public string Habitat { get; set; } = string.Empty; // Animal habitat
        public double Height { get; set; } // Height of the animal in meters
        public double Weight { get; set; } // Weight of the animal in kilograms


    }
}
